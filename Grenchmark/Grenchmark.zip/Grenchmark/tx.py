#! /usr/bin/env python

__author__ = 'Alexandru Iosup'
__email__ = 'A.Iosup at ewi.tudelft.nl'
__file__ = 'AISystemUtil.py'
__version__ = '1.0'
#__name__ = 'Gnutella Crawler Test' 
#! /usr/bin/env python

__author__ = 'Alexandru Iosup';
__email__ = 'A.Iosup at ewi.tudelft.nl';
__file__ = 'AISystemUtil.py';
__version__ = '1.0';
#__name__ = 'System Utils'
 
import sys
import os 


child = os.popen("sleep 600")
child.read()
print "hello :)"
   